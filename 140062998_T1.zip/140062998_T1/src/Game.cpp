#include "Game.h"
#include <stdio.h>
#define INCLUDE_SDL_IMAGE
#define INCLUDE_SDL_MIXER
#include "SDL_include.h"

Game::Game(const char* title, int width, int height){

}

Game::~Game(){
    //dtor
}


Game& Game::GetInstance(){
            if(instance != nullptr)
                return *instance;
            else
                Game* instance = new Game("Lucas Cardoso 140062998", 1024, 600);
        }


/*
bool Game::init(const char* title, int width, int height) {

	if(SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) == 0){
    	    m_pWindow = SDL_CreateWindow(title, width, height);

 	   if(m_pWindow == NULL){

        	std::cout << "SDL Error: Failed to create window: " << SDL_GetError() << std::endl;
        	SDL_Quit();
        	return false;
		}


	}
}*/
