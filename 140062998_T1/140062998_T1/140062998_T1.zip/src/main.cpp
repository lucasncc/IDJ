#include "Game.h"

int main(int argc, char* args[]){
  Game::GetInstance().Run();
  return 0;
}


